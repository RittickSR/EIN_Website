<!DOCTYPE HTML>
<html>
<head>
<title> Enter Otp </title>   
    <link rel="stylesheet" type="text/css" href="style/otp.css">
</head>
<body>
    <div id="login-box">   
     
        <h1> Enter OTP </h1>
        <form id="sign-form" method="post" action="otp.php"> 

        <input type="text" name="otp" placeholder="****" maxlength=4/>

        <input type="submit" name="submit" value="submit"/>
        </form>     
    </div>    
</body>    
</html>
        
        