<?php
unset($_SESSION['usrname']);


header('Location: index.php');
?>