<?php
$con= mysqli_connect('localhost','root','','sample') or die('UNABLE TO CONNECT');
mysqli_select_db($con,'sample');

?>